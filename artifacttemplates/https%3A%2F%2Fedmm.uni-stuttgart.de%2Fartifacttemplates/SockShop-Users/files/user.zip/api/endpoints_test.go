package api

/// needs actual tests

import "testing"

func TestMakeEndpoints(t *testing.T) {
	//	eps := MakeEndpoints(TestService)
}

func TestMakeLoginEndpoint(t *testing.T) {
	//	l := MakeLoginEndpoint(TestService)
}

func TestMakeRegisterEndpoint(t *testing.T) {
	//	r := MakeRegisterEndpoint(TestService)
}
